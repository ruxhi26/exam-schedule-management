<?php
require_once "../../includes/auth.php"; require_admin(); require_once "../../config/db.php";
if($_SERVER["REQUEST_METHOD"]==="POST"){ $name=trim($_POST["room_name"]); $cap=(int)$_POST["capacity"]; $s=$conn->prepare("INSERT INTO rooms(room_name,capacity) VALUES(?,?)"); $s->bind_param("si",$name,$cap); $s->execute(); }
if(isset($_GET["delete"])){ $id=(int)$_GET["delete"]; $s=$conn->prepare("DELETE FROM rooms WHERE room_id=?"); $s->bind_param("i",$id); $s->execute(); header("Location:index.php"); exit();}
$r=$conn->query("SELECT * FROM rooms ORDER BY room_id DESC");
?>
<!DOCTYPE html><html><head><title>Rooms</title><link rel="stylesheet" href="../../assets/css/style.css"></head><body><div class="container">
<div class="card"><h2>Room Management</h2><form method="post"><label>Room Name</label><input name="room_name" required><label>Capacity</label><input type="number" name="capacity" min="1" required><button class="btn btn-success">Add Room</button></form></div>
<div class="card"><table><tr><th>ID</th><th>Room</th><th>Capacity</th><th>Action</th></tr><?php while($x=$r->fetch_assoc()):?><tr><td><?=$x['room_id']?></td><td><?=htmlspecialchars($x['room_name'])?></td><td><?=$x['capacity']?></td><td><a class="btn btn-danger" href="?delete=<?=$x['room_id']?>" onclick="return confirm('Delete room?')">Delete</a></td></tr><?php endwhile;?></table></div><a href="../dashboard.php">← Dashboard</a></div></body></html>