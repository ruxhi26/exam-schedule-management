<?php
require_once "../../includes/auth.php"; require_admin(); require_once "../../config/db.php";
if($_SERVER["REQUEST_METHOD"]==="POST"){
 $sid=(int)$_POST["subject_id"]; $rid=(int)$_POST["room_id"]; $date=$_POST["exam_date"]; $time=$_POST["exam_time"];
 $s=$conn->prepare("INSERT INTO exams(subject_id,room_id,exam_date,exam_time) VALUES(?,?,?,?)"); $s->bind_param("iiss",$sid,$rid,$date,$time); $s->execute();
}
if(isset($_GET["delete"])){ $id=(int)$_GET["delete"]; $s=$conn->prepare("DELETE FROM exams WHERE exam_id=?"); $s->bind_param("i",$id); $s->execute(); header("Location:index.php"); exit();}
$subs=$conn->query("SELECT * FROM subjects ORDER BY subject_name"); $rooms=$conn->query("SELECT * FROM rooms ORDER BY room_name");
$exams=$conn->query("SELECT e.*,s.subject_code,s.subject_name,r.room_name FROM exams e JOIN subjects s ON e.subject_id=s.subject_id JOIN rooms r ON e.room_id=r.room_id ORDER BY e.exam_date,e.exam_time");
?>
<!DOCTYPE html><html><head><title>Exam Schedules</title><link rel="stylesheet" href="../../assets/css/style.css"></head><body><div class="container">
<div class="card"><h2>Create Exam Schedule</h2><form method="post"><label>Subject</label><select name="subject_id" required><?php while($s=$subs->fetch_assoc()):?><option value="<?=$s['subject_id']?>"><?=htmlspecialchars($s['subject_code']." - ".$s['subject_name'])?></option><?php endwhile;?></select>
<label>Room</label><select name="room_id" required><?php while($r=$rooms->fetch_assoc()):?><option value="<?=$r['room_id']?>"><?=htmlspecialchars($r['room_name'])?></option><?php endwhile;?></select>
<label>Date</label><input type="date" name="exam_date" required><label>Time</label><input type="time" name="exam_time" required><button class="btn btn-success">Create Schedule</button></form></div>
<div class="card"><table><tr><th>Subject</th><th>Date</th><th>Time</th><th>Room</th><th>Action</th></tr><?php while($e=$exams->fetch_assoc()):?><tr><td><?=htmlspecialchars($e['subject_code']." - ".$e['subject_name'])?></td><td><?=$e['exam_date']?></td><td><?=$e['exam_time']?></td><td><?=htmlspecialchars($e['room_name'])?></td><td><a class="btn btn-danger" href="?delete=<?=$e['exam_id']?>" onclick="return confirm('Delete schedule?')">Delete</a></td></tr><?php endwhile;?></table></div><a href="../dashboard.php">← Dashboard</a></div></body></html>