<?php
require_once "../../includes/auth.php"; require_admin(); require_once "../../config/db.php";
$result = $conn->query("SELECT * FROM subjects ORDER BY subject_id DESC");
?>
<!DOCTYPE html><html><head><title>Subjects</title><link rel="stylesheet" href="../../assets/css/style.css"></head>
<body><div class="navbar"><b>Subject Management</b><div><a href="../dashboard.php">Dashboard</a><a href="../../logout.php">Logout</a></div></div>
<div class="container"><div class="card"><a class="btn btn-success" href="add.php">+ Add Subject</a></div>
<div class="card"><table><tr><th>ID</th><th>Code</th><th>Subject Name</th><th>Actions</th></tr>
<?php while($row=$result->fetch_assoc()): ?><tr><td><?=$row['subject_id']?></td><td><?=htmlspecialchars($row['subject_code'])?></td><td><?=htmlspecialchars($row['subject_name'])?></td><td>
<a class="btn" href="edit.php?id=<?=$row['subject_id']?>">Edit</a>
<a class="btn btn-danger" href="delete.php?id=<?=$row['subject_id']?>" onclick="return confirm('Delete this subject?')">Delete</a></td></tr><?php endwhile; ?>
</table></div></div></body></html>