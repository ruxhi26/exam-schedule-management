<?php
require_once "../includes/auth.php"; require_student(); require_once "../config/db.php";
$q=trim($_GET["q"]??""); $like="%".$q."%";
$stmt=$conn->prepare("SELECT e.exam_date,e.exam_time,s.subject_code,s.subject_name,r.room_name FROM exams e JOIN subjects s ON e.subject_id=s.subject_id JOIN rooms r ON e.room_id=r.room_id WHERE s.subject_name LIKE ? OR s.subject_code LIKE ? OR r.room_name LIKE ? ORDER BY e.exam_date,e.exam_time");
$stmt->bind_param("sss",$like,$like,$like); $stmt->execute(); $result=$stmt->get_result();
?>
<!DOCTYPE html><html><head><title>Student Schedule</title><link rel="stylesheet" href="../assets/css/style.css"></head><body><div class="navbar"><b>Student Schedule</b><div><a href="../index.php">Home</a><a href="../logout.php">Logout</a></div></div>
<div class="container"><h2>Welcome, <?=htmlspecialchars($_SESSION["student_name"])?></h2><div class="card"><form><label>Search subject, code or room</label><input name="q" value="<?=htmlspecialchars($q)?>" placeholder="e.g. Mathematics"><button class="btn">Search</button></form></div>
<div class="card"><table><tr><th>Subject</th><th>Date</th><th>Time</th><th>Room</th></tr><?php while($e=$result->fetch_assoc()):?><tr><td><?=htmlspecialchars($e["subject_code"]." - ".$e["subject_name"])?></td><td><?=$e["exam_date"]?></td><td><?=$e["exam_time"]?></td><td><?=htmlspecialchars($e["room_name"])?></td></tr><?php endwhile;?></table></div></div></body></html>