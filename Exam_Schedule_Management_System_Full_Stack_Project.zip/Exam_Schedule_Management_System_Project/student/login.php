<?php
session_start(); require_once "../config/db.php"; $error="";
if($_SERVER["REQUEST_METHOD"]==="POST"){
 $roll=trim($_POST["roll_no"]);
 $s=$conn->prepare("SELECT student_id,student_name,roll_no,class FROM students WHERE roll_no=?"); $s->bind_param("s",$roll); $s->execute(); $st=$s->get_result()->fetch_assoc();
 if($st){$_SESSION["student_id"]=$st["student_id"];$_SESSION["student_name"]=$st["student_name"];header("Location:index.php");exit();} $error="Student not found.";
}
?>
<!DOCTYPE html><html><head><title>Student Login</title><link rel="stylesheet" href="../assets/css/style.css"></head><body><div class="container"><div class="card" style="max-width:450px;margin:80px auto">
<h2>Student Login</h2><?php if($error):?><div class="alert"><?=$error?></div><?php endif;?><form method="post"><label>Roll Number</label><input name="roll_no" required><button class="btn">Continue</button></form><p class="small">Demo roll number: 22</p><a href="../index.php">← Home</a></div></div></body></html>